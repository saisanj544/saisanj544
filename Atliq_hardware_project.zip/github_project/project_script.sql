use gdb023;

select *
from dim_customer;

select *
from dim_product;

select *
from fact_gross_price;

select *
from fact_manufacturing_cost;

select *
from fact_pre_invoice_deductions;

select *
from fact_sales_monthly;

/*Q1) Provide the list of markets in which customer "Atliq Exclusive" operates its business in the APAC region. */

select market
from dim_customer
where region = 'APAC' and customer = 'Atliq Exclusive' ;

/*Q2) What is the percentage of unique product increase in 2021 vs. 2020? 
The final output contains these fields, unique_products_2020 ,unique_products_2021 ,percentage_chg*/

with cte1 as
(select count(distinct product_code) as unique_products_2020
from fact_gross_price
where fiscal_year = 2020),

cte2 as  (select count(distinct product_code) as unique_products_2021 
from fact_gross_price
where fiscal_year = 2021)

select cte1.unique_products_2020,cte2.unique_products_2021,
(cte2.unique_products_2021-cte1.unique_products_2020)*100/cte1.unique_products_2020 as percentage_chg
from cte1,cte2;

/*Q3) Provide a report with all the unique product counts for each segment and sort them in descending order of product counts.
The final output contains 2 fields, segment, product_count*/

select segment, count(distinct product) as product_count
from dim_product
group by segment
order by product_count;

/*Q4) Follow-up: Which segment had the most increase in unique products in 2021 vs 2020? 
The final output contains these fields, segment ,product_count_2020, product_count_2021 difference */

with cte1 as (select d.segment as s, 
count(d.product) as product_count_2020
from  dim_product as d inner join fact_gross_price as f
on  d.product_code = f.product_code
where f.fiscal_year = 2020
group by d.segment),

cte2 as (select  segment as s,
count(d.product) as product_count_2021
from  dim_product as d inner join fact_gross_price as f
on  d.product_code = f.product_code
where f.fiscal_year = 2021
group by d.segment)

select cte1.s as segment ,
cte1.product_count_2020,
cte2.product_count_2021,
(cte2.product_count_2021-cte1.product_count_2020) as difference
from cte1 inner join cte2
on cte1.s = cte2.s;


/*Q5) Get the products that have the highest and lowest manufacturing costs.
The final output should contain these fields, product_code ,product manufacturing_cost*/

select d.product_code,d.product,f.manufacturing_cost
from dim_product as d inner join fact_manufacturing_cost as f
on d.product_code = f.product_code
where f.manufacturing_cost = (select max(manufacturing_cost) from fact_manufacturing_cost) or
f.manufacturing_cost = (select min(manufacturing_cost) from fact_manufacturing_cost) 
order by f.manufacturing_cost  desc;

/* Q6 )Generate a report which contains the top 5 customers who received an average high pre_invoice_discount_pct for the fiscal year 2021 and in the Indian market. The final output contains these fields, customer_code ,customer, average_discount_percentage*/

select  d.customer_code,d.customer,f.pre_invoice_discount_pct
 as  average_discount_percentage
from dim_customer as d inner join fact_pre_invoice_deductions as f
on d.customer_code = f.customer_code
where f.fiscal_year = 2021 and d.market= 'India'
limit 5 ;


/* 7Q) Get the complete report of the Gross sales amount for the customer “Atliq Exclusive” for each month . This analysis helps to get an idea of low and high-performing months and take strategic decisions. The final report contains these columns: Month, Year, Gross sales Amount */

select month(s.date) as Month_, m.cost_year , sum(s.sold_quantity*m.manufacturing_cost) as gross_sales_amount
from fact_manufacturing_cost as m inner join fact_sales_monthly as s
on m.product_code = s.product_code and s.fiscal_year = m.cost_year
group by Month_,m.cost_year
order by m.cost_year,Month_;

/* Q8) In which quarter of 2020, got the maximum total_sold_quantity? The final output contains these fields sorted by the total_sold_quantity, Quarter total_sold_quantity */

select sum(sold_quantity) as q,month(date) as date_
from fact_sales_monthly as f
where Year(date) = 2020 
group by month(date);

/* Q9) Which channel helped to bring more gross sales in the fiscal year 2021 and the percentage of contribution? The final output contains these fields, channel, gross_sales_mln percentage */

select d.channel,sum(f.sold_quantity)*100/(select sum(sold_quantity) from fact_sales_monthly where  fiscal_year = 2021) as gross_sales_mln_percentage
from dim_customer as d left join fact_sales_monthly as f
on d.customer_code = f.customer_code
where f.fiscal_year = 2021
group by d.channel;

/* 10. Get the Top 3 products in each division that have a high total_sold_quantity in the fiscal_year 2021? The final output contains these fields  division, product_code ,
product, total_sold_quantity ,rank_order */

with cte1 as (select d.division ,d.product_code,d.product,sum(f.sold_quantity) as total_sold_quantity
from dim_product as d inner join fact_sales_monthly as f
on d.product_code = f.product_code
where f.fiscal_year = 2021
group by d.product,d.division,d.product_code),

cte2 as (select * , dense_rank() over( partition by cte1.division order by cte1.total_sold_quantity desc) as rank_order
from cte1)
select *
from cte2
where rank_order <= 3;

































